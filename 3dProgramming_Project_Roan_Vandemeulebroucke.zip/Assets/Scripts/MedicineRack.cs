using UnityEngine;

public class MedicineRack : MonoBehaviour
{
    [Header("Rack Info")]
    public string medicineType = "A";  // Set this in the Inspector (e.g. A, B, C, D, E)
}
