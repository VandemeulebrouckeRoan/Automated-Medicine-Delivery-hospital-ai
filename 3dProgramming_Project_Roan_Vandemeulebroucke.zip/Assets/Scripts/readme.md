## Agent Training Philosophy

This project uses a highly detailed and guided reward system, along with many observations, to train a robotic delivery agent in a simulated hospital environment. The goal is for the agent to learn to pick up and deliver the correct type and amount of medicine to the correct room, efficiently and reliably.

### 🧠 Why So Many Observations?

The agent receives **21 observations per decision step**, including:

- **One-hot encoded medicine type request**
- **Pickup status** (e.g., has it picked up medicine yet?)
- **Relative vectors and distances to the target rack and room**
- **Alignment with movement directions**
- **Progress toward completing the delivery**

This large observation space gives the agent full context about its task, location, and goals. It allows for more intelligent behavior and reduces the chance of getting stuck or confused. Even if some observations seem redundant, they improve the learning signal and stabilize training.

---

### 🎯 Why So Many Small Rewards and Penalties?

Rather than relying on sparse or binary rewards (like only rewarding success at the end), this script uses **frequent, small feedback loops** to:

- Encourage movement in the right direction
- Discourage spinning in place or lingering too long at racks
- Reward directional alignment
- Apply penalties for bumping into walls or racks
- Provide immediate feedback on wrong pickups or missed requests

This "dense feedback" approach teaches the agent **not just what to do**, but **how to do it better**, allowing for:

- Faster convergence during training
- Reduced randomness in behavior
- More interpretable and adjustable learning process

---

### 🔄 Task Phases and Reward Logic

The training process is broken into **task phases**, each with different logic and rewards:

1. **Going to the Rack**
   - Rewards for getting closer and aligning with the correct rack
   - Penalties for spinning or bumping into the wrong racks

2. **Picking Up Medicine**
   - Reward per correct unit picked up
   - Bonus for completing a full pickup
   - Penalty for wrong types or overcapacity

3. **Leaving the Rack**
   - Reward for successfully exiting the rack area
   - Directional reward for moving toward the room

4. **Delivering to the Room**
   - Progressive reward as it gets closer to the correct room
   - Bonus for successful delivery
   - Extra reward if it completes multiple deliveries in a row

---

### 💡 Final Notes

This approach may look reward-heavy and observation-dense, but it's **very intentional**. It helps guide the agent with clear, interpretable signals while maintaining flexibility for debugging and expansion.

> The better and more specific the guidance, the faster and more stable the learning.

