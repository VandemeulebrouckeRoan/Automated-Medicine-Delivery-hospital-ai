
using UnityEngine;

public class Room : MonoBehaviour
{
    public string roomName;
    public int roomNumber;

    private void Start()
    {
        // Set the name of the GameObject to include the room number for easier identification
        if (string.IsNullOrEmpty(roomName))
        {
            roomName = $"Room {roomNumber}";
        }
        gameObject.name = roomName;
    }
}