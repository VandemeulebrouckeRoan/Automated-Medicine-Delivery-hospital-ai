using UnityEngine;

public class MedicineRequest
{
    public string medicineType;
    public int amount;
    public Transform targetRoom;
}
