using System.Collections.Generic;
using UnityEngine;
using Unity.MLAgents;
using Unity.MLAgents.Sensors;
using Unity.MLAgents.Actuators;
using UnityEngine.UI;
using TMPro;

public class deliveryagent : Agent
{
    [Header("Request Settings")]
    public List<string> medicineTypes = new List<string> { "A", "B", "C", "D", "E" };
    public List<Transform> allRooms;

    private int deliveriesCompleted = 0;
    public int deliveriesBeforeReset = 3; // This was for training purposes you can always make it higher when the model is trained
    [SerializeField] private string deliveryStatusText = "Deliveries: 0/3";

    [Header("UI References")]
    public TextMeshPro deliveryCounterText;

    [Header("Audio References")]
    public AudioClip myClip;
    private AudioSource audioSource;

    [Header("Request State")]
    public string requestedType;
    public int requestedAmount;
    public Transform targetRoom;

    [Header("Pickup Settings")]
    public int maxCarry = 10;
    private int currentlyHeld = 0;
    private bool medicinePicked = false;
    private bool isLeavingRack = false;
    private bool hasLeftRack = false;
    private bool isGoingToRoom = false;
    private bool isAtRoom = false;

    [Header("Rack Setup")]
    public List<Transform> medicineRacks;
    private Transform correctRack;

    [Header("Live Trigger State")]
    private Collider currentTrigger;
    private Collider rackTrigger;
    private Collider roomTrigger;

    [Header("Live Debug (Inspector Only)")]
    [SerializeField] private string currentTargetRoomName;
    [SerializeField] private Vector3 currentTargetRoomPosition;
    [SerializeField] private string currentRequestText;
    [SerializeField] private int heldCount;
    [SerializeField] private float distanceToCorrectRack;
    [SerializeField] private float distanceToTargetRoom;
    [SerializeField] private string taskPhase = "Collecting Medicine";

    [Header("Movement Settings")]
    public float moveSpeed = 5f;
    public float turnSpeed = 150f;
    private Rigidbody rb;

    [Header("Spawn Settings")]
    public Transform spawnPoint;

    [Header("Episode Settings")]
    public int maxSteps = 5000;
    private Vector3 lastPosition;
    private Quaternion lastRotation;
    private float cumulativeAngleChange = 0f;
    private float spinPenaltyThreshold = 720f; // rotation threshold for spinning
    private float movementThreshold = 0.5f; // min distance to consider moving
    private float lastActionTime = 0f;
    private int consecutiveSpinActions = 0;

    public override void Initialize()
    {
        rb = GetComponent<Rigidbody>();
        lastPosition = transform.position;
        lastRotation = transform.rotation;
        MaxStep = maxSteps;
    }

    public override void OnEpisodeBegin()
    {
        deliveriesCompleted = 0;
        deliveryStatusText = $"Deliveries: {deliveriesCompleted}/{deliveriesBeforeReset}";
        UpdateDeliveryDisplay();
        ResetPosition();
        GenerateNewRequest();
        lastPosition = transform.position;
        lastRotation = transform.rotation;
        cumulativeAngleChange = 0f;
        consecutiveSpinActions = 0;
        medicinePicked = false;
        isLeavingRack = false;
        hasLeftRack = false;
        isGoingToRoom = false;
        isAtRoom = false;
        taskPhase = "Collecting Medicine";
    }

    private void UpdateDeliveryDisplay()
    {
        if (deliveryCounterText != null)
        {
            deliveryCounterText.text = $"Deliverys: {deliveriesCompleted}";
        }
    }


    public override void CollectObservations(VectorSensor sensor)
    {
        // Medicine type one-hot encoding (5 observations)
        foreach (string type in medicineTypes)
        {
            sensor.AddObservation(type == requestedType ? 1f : 0f);
        }

        // Request information (5 observations)
        sensor.AddObservation(requestedAmount);
        sensor.AddObservation(currentlyHeld);
        sensor.AddObservation(medicinePicked ? 1f : 0f);
        sensor.AddObservation(isLeavingRack ? 1f : 0f);
        sensor.AddObservation(hasLeftRack ? 1f : 0f);

        // Normalized progress toward completing the request (1 observation)
        sensor.AddObservation((float)currentlyHeld / requestedAmount);

        // Room information (5 observations)
        Vector3 toRoom = targetRoom.position - transform.position;
        sensor.AddObservation(toRoom.normalized);
        distanceToTargetRoom = Vector3.Distance(transform.position, targetRoom.position);
        sensor.AddObservation(distanceToTargetRoom / 20f);
        sensor.AddObservation(Vector3.Dot(transform.forward, toRoom.normalized)); // facing direction I know this is ment to be .right because i made my custom robot facing to the wrong direction but it worked realy good so i left it like this

        // Rack information (5 observations)
        if (correctRack != null)
        {
            Vector3 toRack = correctRack.position - transform.position;
            sensor.AddObservation(toRack.normalized);
            distanceToCorrectRack = Vector3.Distance(transform.position, correctRack.position);
            sensor.AddObservation(distanceToCorrectRack / 20f);
            sensor.AddObservation(Vector3.Dot(transform.forward, toRack.normalized)); // facing direction I know this is ment to be .right because i made my custom robot facing to the wrong direction but it worked realy good so i left it like this

            // Draw line to target rack for visualization (no observations)
            if (!medicinePicked)
            {
                Debug.DrawLine(transform.position, correctRack.position, Color.green, 0.1f);
            }
            else
            {
                Debug.DrawLine(transform.position, correctRack.position, Color.red, 0.1f);
            }
        }
        else
        {
            sensor.AddObservation(Vector3.zero);
            sensor.AddObservation(1f);
            sensor.AddObservation(0f);
            distanceToCorrectRack = 0f;
        }

        // Draw line to target room for visualization (no observations)
        if (targetRoom != null)
        {
            if (medicinePicked)
            {
                Debug.DrawLine(transform.position, targetRoom.position, Color.green, 0.1f);
            }
            else
            {
                Debug.DrawLine(transform.position, targetRoom.position, Color.red, 0.1f);
            }
        }

        // Total: 5 + 5 + 1 + 5 + 5 = 21 observations
    }

    public override void OnActionReceived(ActionBuffers actions)
    {
        int move = actions.DiscreteActions[0];
        int turn = actions.DiscreteActions[1];
        int act = actions.DiscreteActions[2];

        // Track time between actions to detect stalling
        float timeSinceLastAction = Time.time - lastActionTime;
        lastActionTime = Time.time;

        // Check for spinning behavior
        float angleChange = Quaternion.Angle(lastRotation, transform.rotation);
        cumulativeAngleChange += angleChange;
        float distanceMoved = Vector3.Distance(transform.position, lastPosition);

        // If we're spinning a lot but not moving much
        if (cumulativeAngleChange > spinPenaltyThreshold && distanceMoved < movementThreshold)
        {
            AddReward(-0.5f);
            cumulativeAngleChange = 0f;
            Debug.Log("🔄 Spinning penalty applied");
        }

        // Store current state for next frame comparison
        lastPosition = transform.position;
        lastRotation = transform.rotation;

        // Calculate closeness reward based on current task phase
        if (!medicinePicked && currentlyHeld < requestedAmount)
        {
            // Phase 1: Go to the correct rack
            taskPhase = "Going to Rack";

            if (correctRack != null)
            {
                float distanceToTarget = Vector3.Distance(transform.position, correctRack.position);
                float previousReward = Mathf.Clamp01(1f - distanceToTarget / 10f);

                // The closer we are, the more reward we get
                if (distanceToTarget < 5f)
                {
                    AddReward(0.03f * previousReward);
                }
                else
                {
                    AddReward(0.01f * previousReward);
                }
            }
        }

        else if (medicinePicked && !hasLeftRack)
        {
            // Phase 2: Leave the rack trigger zone and move 2 units away
            taskPhase = "Leaving Rack";

            if (correctRack != null)
            {
                // Calculate distance from rack
                float distanceFromRack = Vector3.Distance(transform.position, correctRack.position);

                // Make this easier - reduce required distance to 2 units
                if (distanceFromRack >= 2f)
                {
                    hasLeftRack = true;
                    isGoingToRoom = true;
                    AddReward(+50f); // Reward for getting far enough from the rack
                    Debug.Log($"🏆 Successfully moved {distanceFromRack:F2} units away from the rack!");
                    taskPhase = "Going to Room";
                }

                else
                {
                    // Provide stronger rewards for moving away from the rack
                    float previousReward = Mathf.Clamp01(distanceFromRack / 2f);
                    AddReward(0.1f * previousReward);

                    // Apply stronger penalties when very close to the rack
                    if (distanceFromRack < 1f)
                    {
                        AddReward(-0.05f); // Stronger penalty to discourage lingering
                    }
                }

                // Add a strong directional reward toward the target room even in the leaving rack phase
                if (targetRoom != null)
                {
                    Vector3 toRoom = targetRoom.position - transform.position;
                    Vector3 awayFromRack = transform.position - correctRack.position;

                    // Check if agent is moving in the general direction of the room while also away from rack
                    float dotToRoom = Vector3.Dot(awayFromRack.normalized, toRoom.normalized);
                    if (dotToRoom > 0.5f)
                    {
                        AddReward(0.15f);
                    }
                }
            }
        }

        else if (hasLeftRack && isGoingToRoom && !isAtRoom)
        {
            // Phase 3: Go to the target room
            taskPhase = "Going to Room";

            if (targetRoom != null)
            {
                float distanceToRoom = Vector3.Distance(transform.position, targetRoom.position);

                // Progressive rewards that increase as agent gets closer to room
                float maxDistance = 15f;
                float normalizedDistance = Mathf.Clamp01(distanceToRoom / maxDistance);
                float proximityReward = 1f - normalizedDistance; // 0 when far, 1 when at room

                // Apply a small reward based on proximity
                AddReward(0.03f * proximityReward);


                // Additional threshold rewards
                if (distanceToRoom < 2f)
                {
                    AddReward(0.1f);
                }
            }
        }

        // Wall avoidance i don' reset it because it hasn't touched the wall yet
        float proximityCheckRadius = 0.5f;
        Collider[] nearby = Physics.OverlapSphere(transform.position, proximityCheckRadius);
        foreach (var col in nearby)
        {
            if (col.CompareTag("Wall"))
            {
                AddReward(-1f);
                break;
            }
        }


        // Movement logic
        if (move == 1)
        {
            Vector3 movement = transform.right * moveSpeed * Time.fixedDeltaTime; // Move forward but because of the way the robot is facing it will be to the right
            rb.MovePosition(rb.position + movement);

            if (!medicinePicked && currentlyHeld < requestedAmount && correctRack != null)
            {
                // Phase 1: Moving toward the correct rack
                Vector3 toRack = correctRack.position - transform.position;
                float dot = Vector3.Dot(movement.normalized, toRack.normalized);

                // Reward based on direction
                if (dot > 0.7f)
                {
                    AddReward(0.02f);
                }
            }

            else if (medicinePicked && !hasLeftRack && correctRack != null)
            {
                // Phase 2: Moving away from the rack
                Vector3 awayFromRack = transform.position - correctRack.position;
                float dot = Vector3.Dot(movement.normalized, awayFromRack.normalized);

                // Reward based on direction
                if (dot > 0.7f)
                {
                    AddReward(0.05f);
                }
                else if (dot < 0f)
                {
                    AddReward(-0.02f);
                }
            }


            else if (hasLeftRack && isGoingToRoom && !isAtRoom && targetRoom != null)
            {
                // Phase 3: Moving toward the target room
                Vector3 toRoom = targetRoom.position - transform.position;
                float distanceToRoom = toRoom.magnitude;
                float dot = Vector3.Dot(movement.normalized, toRoom.normalized);

                // Reward based on direction
                if (dot > 0.7f)
                {
                    AddReward(0.05f);
                }
                else if (dot < -0.5f)
                {
                    AddReward(-0.02f);
                }
            }
        }

        // Turning logic
        if (turn == 1)
        {
            Quaternion rotation = Quaternion.Euler(0, -turnSpeed * Time.fixedDeltaTime, 0);
            rb.MoveRotation(rb.rotation * rotation);

            // Track consecutive turn actions without movement
            if (move == 0)
            {
                consecutiveSpinActions++;
                if (consecutiveSpinActions > 10)
                {
                    AddReward(-0.05f);
                    Debug.Log("⚠️ Consecutive turning without movement penalty");
                }
            }
            else
            {
                consecutiveSpinActions = 0;
            }
        }
        else if (turn == 2)
        {
            Quaternion rotation = Quaternion.Euler(0, turnSpeed * Time.fixedDeltaTime, 0);
            rb.MoveRotation(rb.rotation * rotation);

            // Track consecutive turn actions without movement
            if (move == 0)
            {
                consecutiveSpinActions++;
                if (consecutiveSpinActions > 10)
                {
                    AddReward(-0.05f);
                    Debug.Log("⚠️ Consecutive turning without movement penalty");
                }
            }
            else
            {
                consecutiveSpinActions = 0;
            }
        }
        else
        {
            consecutiveSpinActions = 0;
        }



        // Penalty for turning without moving
        if (move == 0 && (turn == 1 || turn == 2))
        {
            AddReward(-0.01f);
        }

        // Penalty for doing nothing
        if (move == 0 && turn == 0 && act == 0)
        {
            AddReward(-0.005f);
        }

        // Action logic for medicine pickup and room interaction
        if (act == 1 && currentTrigger != null)
        {
            MedicineRack rack = currentTrigger.GetComponent<MedicineRack>();

            // Check if we're at a medicine rack
            if (rack != null && !medicinePicked)
            {
                string type = rack.medicineType.ToUpper();

                // Check if the rack has the requested medicine
                if (type == requestedType.ToUpper())
                {

                    // Check if we can pick up the medicine
                    if (currentlyHeld < requestedAmount && currentlyHeld < maxCarry)
                    {
                        currentlyHeld++;
                        heldCount = currentlyHeld;
                        AddReward(+10f); // Reward for successful pickup
                        Debug.Log($"✅ Picked up {type} ({currentlyHeld}/{requestedAmount})");

                        // Mark as picked up if we've collected all required medicine
                        if (currentlyHeld >= requestedAmount)
                        {
                            medicinePicked = true;
                            isLeavingRack = true;
                            rackTrigger = currentTrigger;
                            taskPhase = "Leaving Rack";

                            // Give an extra bonus reward for collecting all required medicine
                            float completionBonus = 25f; 
                            AddReward(completionBonus);
                            Debug.Log($"🎉 Collected all required medicine! Bonus: +{completionBonus}");
                            Debug.Log("🚚 All medicine collected! Now leaving the rack area.");
                        }
                    }

                    else
                    {
                        AddReward(-0.5f);
                        Debug.Log($"❌ Over capacity: held {currentlyHeld}, requested {requestedAmount}");
                    }
                }

                else
                {
                    AddReward(-1f);
                    Debug.Log($"❌ Wrong type: {type} (wanted {requestedType})");
                }
            }

            // Check if we're at the target room
            Room room = currentTrigger.GetComponent<Room>();
            if (room != null && medicinePicked && currentTrigger.transform == targetRoom)
            {
                // Force completion of delivery even if we didn't properly leave rack
                isAtRoom = true;
                hasLeftRack = true; 
                isGoingToRoom = true;  
                roomTrigger = currentTrigger;
                Debug.Log("🏥 Reached the target room! Delivering medicine!");
                CompleteDelivery();
            }
        }

        CheckRequestCompletion();
    }

    public override void Heuristic(in ActionBuffers actionsOut)
    {
        var d = actionsOut.DiscreteActions;
        d[0] = Input.GetKey(KeyCode.W) ? 1 : 0;
        d[1] = Input.GetKey(KeyCode.A) ? 1 : Input.GetKey(KeyCode.D) ? 2 : 0;
        d[2] = Input.GetKey(KeyCode.Space) ? 1 : 0;
    }

    void OnTriggerEnter(Collider other)
    {
        currentTrigger = other;

        // Handle medicine rack interaction
        MedicineRack rack = other.GetComponent<MedicineRack>();
        if (rack != null && !medicinePicked)
        {
            if (rack.medicineType.ToUpper() == requestedType.ToUpper())
            {
                AddReward(+5f); 
                Debug.Log("🏆 Entered correct rack zone.");
            }
            else
            {
                AddReward(0.25f);
                Debug.Log("⚠️ Entered wrong rack zone.");
            }
        }

        // Handle target room interaction
        Room room = other.GetComponent<Room>();
        if (room != null && other.transform == targetRoom)
        {
            // Modified to give reward even if states aren't perfect
            if (medicinePicked)
            {
                AddReward(+50f); 
                Debug.Log("🏆 Entered target room zone with medicine! Big reward!");

                // Force the state to be correct
                hasLeftRack = true;
                isGoingToRoom = true;
            }
            else
            {
                AddReward(+5f); 
                Debug.Log("⭐ Found target room but need medicine first!");
            }
        }
    }

    void OnTriggerExit(Collider other)
    {
        if (currentTrigger == other)
        {
            currentTrigger = null;
        }

        // Now we're just tracking when we exit the trigger
        if (medicinePicked && isLeavingRack && other == rackTrigger)
        {
            AddReward(+5f); 
            Debug.Log("Left the rack trigger zone, still need to move further away!");
        }
    }

    void OnCollisionEnter(Collision collision)
    {
        // Check for rack collisions
        if (collision.gameObject.GetComponent<MedicineRack>() != null)
        {
            Debug.Log("💥 Hit a rack! Applying penalty.");
            AddReward(-3f); 

            // If we have the medicine and hit a rack, let's help it get unstuck
            if (medicinePicked && !hasLeftRack)
            {
                Vector3 pushDirection = transform.position - collision.transform.position;
                pushDirection.y = 0;
                pushDirection.Normalize();
                rb.AddForce(pushDirection * 5f, ForceMode.Impulse);
                Debug.Log("🔄 Applied push force to help agent get unstuck from rack");
            }
        }
        else if (collision.gameObject.CompareTag("Wall"))
        {
            Debug.Log("💥 Hit a wall! Episode reset.");
            AddReward(-5f); 
            EndEpisode(); 
        }
    }

    void ResetPosition()
    {
        rb.linearVelocity = Vector3.zero;
        rb.angularVelocity = Vector3.zero;

        if (spawnPoint != null)
        {
            transform.position = spawnPoint.position;
            transform.rotation = spawnPoint.rotation;
        }
    }

    void GenerateNewRequest()
    {
        if (allRooms == null || allRooms.Count == 0)
        {
            Debug.LogWarning("🚫 No rooms available!");
            return;
        }

        requestedType = medicineTypes[Random.Range(0, medicineTypes.Count)];
        requestedAmount = Random.Range(1, 5); // Random amount between 1-4
        targetRoom = allRooms[Random.Range(0, allRooms.Count)];

        currentlyHeld = 0;
        heldCount = 0;

        int rackIndex = medicineTypes.IndexOf(requestedType);
        if (rackIndex >= 0 && rackIndex < medicineRacks.Count)
        {
            correctRack = medicineRacks[rackIndex];
        }

        currentTargetRoomName = targetRoom.name;
        currentTargetRoomPosition = targetRoom.position;
        currentRequestText = $"{requestedAmount}x {requestedType} → {targetRoom.name}";

        Debug.Log($"🆕 New Request: {requestedAmount}x {requestedType} → {targetRoom.name}");
    }

    void CheckRequestCompletion()
    {
        if (isAtRoom)
        {
            // Request is fully complete
            return;
        }
        else if (StepCount >= MaxStep)
        {
            // Apply a significant base penalty for not completing the task
            float baseReward = -75f;

            if (hasLeftRack && targetRoom != null)
            {
                // We left the rack but didn't reach the target room
                float distanceToRoom = Vector3.Distance(transform.position, targetRoom.position);
                float maxDistance = 15f; 

                // Calculate how close the agent got to the target room (0 to 1 scale)
                float progressToRoom = Mathf.Clamp01(1f - (distanceToRoom / maxDistance));

                // Only reduce penalty if made significant progress toward room
                if (distanceToRoom < 5f) // Only if fairly close to room
                {
                    float penaltyReduction = 45f * progressToRoom * progressToRoom; // Square for stronger gradient when close
                    baseReward += penaltyReduction;

                    Debug.Log($"⏱️ Max steps reached: Got close to room ({distanceToRoom:F2}m). " +
                              $"Progress: {progressToRoom:P}, Final reward: {baseReward:F1}");
                }
                else
                {
                    Debug.Log($"⏱️ Max steps reached: Too far from target room ({distanceToRoom:F2}m). Full penalty applied.");
                }
            }
            else
            {
                // Either didn't pick up medicine or didn't leave rack area
                baseReward = -100f; 
                Debug.Log($"⏱️ Max steps reached: Failed to leave rack area. Medicine: {currentlyHeld}/{requestedAmount}. Severe penalty applied.");
            }

            AddReward(baseReward);
            EndEpisode();
        }
    }


    void CompleteDelivery()
    {
        Debug.Log("🏁 Request fulfilled! Successfully delivered medicine to the target room!");
        AddReward(+200f); 

        audioSource = gameObject.AddComponent<AudioSource>();
        audioSource.clip = myClip;
        audioSource.Play();

        deliveriesCompleted++;
        deliveryStatusText = $"Deliveries: {deliveriesCompleted}/{deliveriesBeforeReset}";
        UpdateDeliveryDisplay();

        // Check Really big bonus if we have a triple delivery streak my logic is if it can do 3 deliveries in a row it can do 10 or more in a row 
        if (deliveriesCompleted >= deliveriesBeforeReset)
        {
            Debug.Log("🏅🏅🏅 Triple Delivery Streak Achieved! Resetting episode! 🏅🏅🏅");
            AddReward(+200f); 
            EndEpisode();
            return;
        }

        // Immediately generate a new request
        GenerateNewRequest();

        // Reset task-specific variables
        medicinePicked = false;
        isLeavingRack = false;
        hasLeftRack = false;
        isGoingToRoom = false;
        currentlyHeld = 0;
        heldCount = 0;
        isAtRoom = false;

        // Reward for getting a new request and doing it
        AddReward(+25f);  
    }

}